"""Plot the saved climbing experiment and the three fixed ascent routes."""

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

from platformer import LEVELS


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment-dir", type=Path, default=Path(__file__).resolve().parent / "experiments" / "height_curriculum")
    args = parser.parse_args()
    result = json.loads((args.experiment_dir / "results.json").read_text(encoding="utf-8"))
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5), constrained_layout=True)
    for ax, key, title in zip(axes, ("height_test", "old_test"),
                              ("New climbing layouts (held out)", "Original layouts (retention check)")):
        for offset, group, label, color in ((-0.18, "baseline", "Before", "#7295ba"), (0.18, "trained", "After", "#299b86")):
            summaries = result[group][key]
            rates = [r["completion_rate"] * 100 for r in summaries]
            x = [r["stage"] + offset for r in summaries]
            intervals = [[max(0, rates[i] - r["completion_wilson95"][0] * 100) for i, r in enumerate(summaries)],
                         [max(0, r["completion_wilson95"][1] * 100 - rates[i]) for i, r in enumerate(summaries)]]
            ax.bar(x, rates, width=0.34, color=color, label=label, yerr=intervals, capsize=3)
            for position, rate, summary in zip(x, rates, summaries):
                ax.text(position, summary["completion_wilson95"][1] * 100 + 3,
                        f"{rate:g}%", ha="center", fontsize=9)
        ax.set(xticks=[r["stage"] for r in summaries], xlabel="Stage", ylabel="Completion (%)", ylim=(0, 115), title=title)
        ax.legend(loc="lower left")
    count = result["trained"]["height_test"][0]["episodes"]
    fig.suptitle(f"Climbing PPO | seed {result['training_seed']} | {count} layouts/stage | 95% Wilson intervals")
    fig.savefig(args.experiment_dir / "comparison.png", dpi=160)
    plt.close(fig)
    fig, axes = plt.subplots(3, 1, figsize=(12, 8), constrained_layout=True)
    for ax, level in zip(axes, LEVELS[10:]):
        start_y = level.platforms[0].y
        for p in level.platforms:
            ax.add_patch(Rectangle((p.x, start_y - p.y - 20), p.width, 20, facecolor="#299b86"))
        ax.plot(level.goal_x, start_y - level.platforms[-1].y + 30, "v", color="#c98a24")
        ax.set(xlim=(-20, level.world_width + 20), ylim=(-60, start_y - level.platforms[-1].y + 100),
               ylabel="Ascent (px)", title=level.name)
        ax.grid(alpha=0.18)
    axes[-1].set_xlabel("World X (px)")
    fig.savefig(args.experiment_dir / "level_maps.png", dpi=160)
    plt.close(fig)
    print(f"Saved comparison.png and level_maps.png in {args.experiment_dir}")


if __name__ == "__main__":
    main()
