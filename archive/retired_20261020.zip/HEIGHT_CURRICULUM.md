# 高度關卡與 PPO 接續訓練

新增第 11–13 關與三階段隨機攀升關卡。角色持續向右上方攀登，鏡頭同時水平、垂直捲動。新關卡共用一個六動作 PPO 模型，沒有自動起跳或預先寫好的過關控制器。

此頁保存經典物理的高度實驗；目前遊戲預設的新跳躍／衝刺控制見 [DASH_V2.md](DASH_V2.md)。重播本頁模型請使用 `--classic`。

```powershell
# 移除 --agent 即可自己玩。
python game.py --classic --agent --level 13 --trace
python game.py --classic --agent --height-curriculum --stage 3 --trace

# 用新模型遊玩原本的長路線。
python game.py --agent --full-curriculum --stage 4 --policy experiments/height_curriculum/policy.json --trace
```

固定關卡按 `[`／`]` 切換上一關／下一關，包含 11–13 關；原有 1–9、0 快捷鍵保留。攀升模式的 1–3 切換階段，N 換地圖、R 重試。狀態列顯示已落地達成的攀升高度，縮圖顯示整條路線。

![第 13 關通關畫面](artifacts/height_level13.png)

## 新關卡

| 關卡 | 平台數 | 累計攀升 | 世界高度 | 單次上坡落差 |
| --- | ---: | ---: | ---: | ---: |
| 11 Mountain steps | 7 | 520 px | 830 px | 75–100 px |
| 12 High ridge | 9 | 810 px | 1,120 px | 90–110 px |
| 13 Summit marathon | 12 | 1,240 px | 1,550 px | 100–125 px |

![攀升路線](experiments/height_curriculum/level_maps.png)

隨機階段 1 使用 6–8 個平台、40–80 px 上坡落差；階段 2 使用 8–10 個平台、65–105 px 落差；階段 3 使用 10–12 個平台、80–125 px 落差與 50–80 px 中間落點。生成器驗證平台邊界與離散跳躍距離上限；這是幾何檢查，並非所有地圖的求解證明。

## Agent 調整

- 由 `experiments/full_version/policy.json` 接續訓練，沿用 18 維觀測、64 單元隱藏層與六動作。絕對高度和終點高度差以世界高度正規化，局部平台落差仍維持像素尺度；17 維舊模型保持相容。
- 高度世界在首次落上更高平台時，增加 `0.02 × 新增攀升像素` 獎勵；原地跳躍、重複落地和訓練中間起點均不能重領。稀疏獎勵模式不給高度獎勵，原關卡獎勵不變。
- 25% 回合複習原四階段地圖；其餘回合在後期階段也會複習較簡單的攀升地圖。中間平台起點機率由 35% 降至 8.75%，學習率由 0.0003 降至 0.00015。評估一律從第一個平台開始。
- 可選 `target_kl` 在每個 PPO epoch 結束檢查整批 rollout 的近似 KL，超過 0.02 時停止剩餘 epochs，不回滾已完成更新。舊訓練程式預設維持原本行為。
- 僅用驗證資料選模：75% 已見攀升階段通關率加上 25% 原關卡驗證通關率，平手再比較平台覆蓋率、進度與步數。實際選出的更新為階段 1 的 300、階段 2 的 100、階段 3 的 200；最後一次更新不一定最佳。

## 實測結果

seed 42、每階段 400 次更新、8 個環境、每次 256 步，共新增 **2,457,600 環境步數**。各階段有 1,000 張訓練地圖、24 張驗證地圖、100 張測試地圖；種子與幾何雜湊跨集合分離。模型固定後才評估測試集。

| 測試集合 | 原模型 | 新模型 |
| --- | ---: | ---: |
| 攀升 1：山腳 | 100/100 | 100/100 |
| 攀升 2：高嶺 | 100/100 | 100/100 |
| 攀升 3：山頂 | 77/100 | **100/100** |
| 原階段 1：寬平台 | 100/100 | 100/100 |
| 原階段 2：高低差 | 100/100 | 100/100 |
| 原階段 3：窄平台 | 96/100 | **100/100** |
| 原階段 4：長路線 | 86/100 | **98/100** |
| 固定關卡 11／12／13 | 各 100/100 | 各 100/100 |

![微調前後比較](experiments/height_curriculum/comparison.png)

固定關卡採相同的 100 個隨機起點，三關預設起點也都通過；其結果不代表未見地圖泛化。新隨機攀升測試未參與訓練或選模。原四階段測試是既有地圖的能力保留複測，不是新的未見資料。

這是單一訓練 seed 的結果，尚未估計跨 seed 變異。100/100 的 95% Wilson 區間約為 96.3–100%，並非任意地圖的保證；原長路線仍有 2/100 失敗。同時改動獎勵與訓練流程，尚未做個別因素的消融比較。

## 重現

```powershell
# 將重訓結果寫到新目錄，保留已附模型。
python train_height.py --updates-per-stage 400 --output-dir experiments/my_height_run

# 重測新舊模型；應回報 matches_saved_results: true。
python train_height.py --evaluate-only

# 重新產生圖表（需要 requirements-experiments.txt）。
python plot_height.py

# 無視窗播放並輸出截圖、軌跡。
python game.py --classic --agent --level 13 --trace --headless --screenshot artifacts/height_level13.png --trajectory artifacts/height_level13_trajectory.json
python -m unittest -v
```

`--init-policy` 可指定另一個六動作 PPO 模型。載入權重後重設 optimizer，並非完整恢復訓練狀態。自訂初始模型的過往資料曝光情況須另行確認。

資料保存於 `experiments/height_curriculum/`：`manifest.json` 記錄參數、初始模型 SHA-256 與評估幾何；`learning_curve.csv` 記錄驗證表現與 KL；`test_episodes.csv`／`baseline_episodes.csv` 記錄每張攀升測試地圖；`results.json` 包含原模型、新模型結果與實際使用的訓練種子。原模型與過往實驗保持獨立。
