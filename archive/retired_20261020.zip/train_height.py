"""Fine-tune one PPO policy on climbing routes while rehearsing the old curriculum."""

import argparse
import hashlib
import json
from pathlib import Path
import time

import full_curriculum
import height_curriculum as terrain
from platformer import LEVELS
from ppo import PPO, np
from run_experiments import evaluate_procedural, write_csv, write_json
from train_full import evaluate as evaluate_full
from train_ppo import ROOT, evaluate as evaluate_fixed, evaluate_default_start, positive_int


def evaluate(model, stage, split, count):
    return evaluate_procedural(model, stage, split, count,
                               cases=terrain.evaluation_cases(stage, split, count), level_factory=terrain.generate_level)


def prepare_manifest(args):
    cases = {split: [case for stage in terrain.STAGES for case in terrain.evaluation_cases(stage, split, count)]
             for split, count in (("validation", args.validation_layouts), ("test", args.test_layouts))}
    train = [terrain.layout_record(stage, terrain.layout_seed(stage, "train", i))
             for stage in terrain.STAGES for i in range(terrain.TRAIN_LAYOUTS)]
    groups = [set(case["layout_hash"] for case in group) for group in (train, cases["validation"], cases["test"])]
    if any(groups[i] & groups[j] for i in range(3) for j in range(i + 1, 3)):
        raise ValueError("geometry collision between training, validation and test")
    return {"generator": terrain.GENERATOR_VERSION, "numpy_version": np.__version__,
            "parameters": {k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()},
            "initial_policy_sha256": hashlib.sha256(args.init_policy.read_bytes()).hexdigest(),
            "evaluation_cases": cases, "evaluation_start_platform": 0, "evaluation_policy": "greedy",
            "train_layout_seeds": {str(s): [terrain.layout_seed(s, "train", i) for i in range(terrain.TRAIN_LAYOUTS)]
                                   for s in terrain.STAGES},
            "old_curriculum": full_curriculum.GENERATOR_VERSION,
            "fixed_layouts": [terrain_level_record(i) for i in range(11, len(LEVELS) + 1)],
            "selection": "75% seen climbing validation + 25% original validation; tests only after freezing weights"}


def terrain_level_record(number):
    from dataclasses import asdict
    return {"level": number, **asdict(LEVELS[number - 1])}


def final_evaluation(model, count):
    summaries, rows = [], []
    for stage in terrain.STAGES:
        summary, episodes = evaluate(model, stage, "test", count)
        summaries.append(summary)
        rows.extend(episodes)
    return {"height_test": summaries,
            "old_test": [evaluate_full(model, s, "test", count)[0] for s in full_curriculum.STAGES],
            "fixed_test": [{"level": n, **evaluate_fixed(model, count, level=n),
                            "default_start": evaluate_default_start(model, n)} for n in range(11, len(LEVELS) + 1)]}, rows


def train(args):
    manifest = prepare_manifest(args)
    model = PPO.load(args.init_policy, seed=args.seed)
    if model.action_count != 6:
        raise ValueError("climbing training requires a six-action PPO model")
    write_json(args.output_dir / "manifest.json", manifest)
    model.save(args.output_dir / "initial_policy.json")
    started = time.perf_counter()
    history, stage_reports, used = [], [], set()
    steps_per_update = args.num_envs * args.rollout_steps
    for stage in terrain.STAGES:
        collector = terrain.HeightCollector(stage, args.num_envs, args.seed * 100 + stage,
                                             args.rehearsal, args.platform_start_prob)
        checkpoint = args.output_dir / f"stage{stage}_policy.json"
        best_score, selected_update = (-1.,), 0
        completed_total = successes_total = 0
        diagnostics = {"entropy": 0., "approx_kl": 0., "clip_fraction": 0., "value_mse": 0., "epochs_run": 0, "rollout_kl": 0.}
        for iteration in range(args.updates_per_stage + 1):
            fraction = iteration / args.updates_per_stage
            # Reduce exploratory resets and step size toward the end of each stage.
            collector.platform_start_prob = args.platform_start_prob * (1 - 0.75 * fraction)
            learning_rate = args.learning_rate * (1 - 0.5 * fraction)
            if iteration:
                samples, completed, successes = collector.collect(model, args.rollout_steps)
                completed_total += completed
                successes_total += successes
                diagnostics = model.update(*samples, learning_rate=learning_rate, entropy_coef=args.entropy,
                                           target_kl=args.target_kl)
            if iteration % args.eval_every == 0 or iteration == args.updates_per_stage:
                climbing = [evaluate(model, s, "validation", args.validation_layouts)[0] for s in range(1, stage + 1)]
                old = [evaluate_full(model, s, "validation", args.validation_layouts)[0] for s in full_curriculum.STAGES]
                completion = float(np.mean([v["completion_rate"] for v in climbing]))
                retained = float(np.mean([v["completion_rate"] for v in old]))
                score = (0.75 * completion + 0.25 * retained,
                         float(np.mean([v["mean_platform_coverage"] for v in climbing])),
                         float(np.mean([v["mean_progress"] for v in climbing])),
                         -float(np.mean([v["mean_steps"] for v in climbing])))
                total_steps = ((stage - 1) * args.updates_per_stage + iteration) * steps_per_update
                history.append({"stage": stage, "update": iteration, "environment_steps": total_steps,
                                "current_completion": climbing[-1]["completion_rate"], "seen_completion": completion,
                                "old_completion": retained, "selection_score": score[0],
                                "learning_rate": learning_rate, "platform_start_probability": collector.platform_start_prob,
                                "training_episodes": completed_total, "training_successes": successes_total, **diagnostics})
                if score > best_score:
                    best_score, selected_update = score, iteration
                    model.save(checkpoint, generator=terrain.GENERATOR_VERSION, training_seed=args.seed,
                               training_stage=stage, selected_update=iteration, reward_mode="shaped", auto_jump=False)
                print(f"height stage={stage} update={iteration}/{args.updates_per_stage} "
                      f"current={climbing[-1]['completion_rate']:.0%} seen={completion:.0%} old={retained:.0%}", flush=True)
                write_csv(args.output_dir / "learning_curve.csv", history)
        used.update(collector.seen_layouts)
        stage_reports.append({"stage": stage, "selected_update": selected_update, "validation_score": best_score[0],
                              "training_episodes": completed_total, "training_successes": successes_total})
        model = PPO.load(checkpoint, seed=args.seed + stage)
    # Freeze checkpoint selection before inspecting any new test outcome.
    model.save(args.output_dir / "policy.json")
    trained, rows = final_evaluation(model, args.test_layouts)
    baseline, baseline_rows = final_evaluation(PPO.load(args.output_dir / "initial_policy.json"), args.test_layouts)
    result = {"generator": terrain.GENERATOR_VERSION, "training_seed": args.seed,
              "environment_steps": len(terrain.STAGES) * args.updates_per_stage * steps_per_update,
              "elapsed_seconds": round(time.perf_counter() - started, 2), "stage_training": stage_reports,
              "trained": trained, "baseline": baseline,
              "used_training_layouts": [{"family": f, "stage": s, "layout_seed": seed} for f, s, seed in sorted(used)],
              "scope": "One training seed. New climbing tests are held out; original tests are retention checks, not new unseen data."}
    write_json(args.output_dir / "results.json", result)
    write_csv(args.output_dir / "test_episodes.csv", rows)
    write_csv(args.output_dir / "baseline_episodes.csv", baseline_rows)
    for before, after in zip(baseline["height_test"], trained["height_test"]):
        print(f"TEST height {after['stage']}: {before['successes']} -> {after['successes']}/{args.test_layouts}", flush=True)
    for fixed in trained["fixed_test"]:
        print(f"FIXED {fixed['level']}: {fixed['successes']}/{args.test_layouts}; default={fixed['default_start']['success']}", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--init-policy", type=Path, default=ROOT / "experiments" / "full_version" / "policy.json")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "experiments" / "height_curriculum")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--updates-per-stage", type=positive_int, default=400)
    parser.add_argument("--num-envs", type=positive_int, default=8)
    parser.add_argument("--rollout-steps", type=positive_int, default=256)
    parser.add_argument("--eval-every", type=positive_int, default=20)
    parser.add_argument("--validation-layouts", type=positive_int, default=24)
    parser.add_argument("--test-layouts", type=positive_int, default=100)
    parser.add_argument("--learning-rate", type=float, default=0.0003)
    parser.add_argument("--entropy", type=float, default=0.02)
    parser.add_argument("--target-kl", type=float, default=0.02)
    parser.add_argument("--rehearsal", type=float, default=0.25)
    parser.add_argument("--platform-start-prob", type=float, default=0.35)
    parser.add_argument("--evaluate-only", action="store_true")
    args = parser.parse_args()
    if args.evaluate_only:
        if not all((args.output_dir / name).is_file() for name in ("manifest.json", "results.json", "policy.json", "initial_policy.json")):
            parser.error("no completed experiment at --output-dir")
        manifest = json.loads((args.output_dir / "manifest.json").read_text(encoding="utf-8"))
        count = manifest["parameters"]["test_layouts"]
        cases = [case for s in terrain.STAGES for case in terrain.evaluation_cases(s, "test", count)]
        fixed = [terrain_level_record(i) for i in range(11, len(LEVELS) + 1)]
        if manifest["generator"] != terrain.GENERATOR_VERSION or cases != manifest["evaluation_cases"]["test"] or json.loads(json.dumps(fixed)) != manifest["fixed_layouts"]:
            parser.error("test geometry differs from saved manifest")
        saved = json.loads((args.output_dir / "results.json").read_text(encoding="utf-8"))
        trained, _ = final_evaluation(PPO.load(args.output_dir / "policy.json"), count)
        baseline, _ = final_evaluation(PPO.load(args.output_dir / "initial_policy.json"), count)
        print(json.dumps({"matches_saved_results": trained == saved["trained"] and baseline == saved["baseline"],
                          "trained": trained}, indent=2))
        return
    if not args.init_policy.is_file():
        parser.error("initial policy does not exist")
    for name in ("learning_rate", "target_kl"):
        if not np.isfinite(getattr(args, name)) or getattr(args, name) <= 0:
            parser.error(f"{name} must be finite and positive")
    if not np.isfinite(args.entropy) or args.entropy < 0:
        parser.error("entropy must be finite and nonnegative")
    if not 0 <= args.rehearsal < 1 or not 0 <= args.platform_start_prob < 1:
        parser.error("rehearsal and platform-start-prob must be in [0, 1)")
    if max(args.validation_layouts, args.test_layouts) >= 100_000:
        parser.error("layout counts must be less than 100000")
    if (args.output_dir / "manifest.json").exists():
        parser.error("experiment exists; choose a new --output-dir")
    train(args)


if __name__ == "__main__":
    main()
