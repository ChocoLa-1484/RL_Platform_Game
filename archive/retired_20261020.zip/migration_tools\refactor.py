"""One-time source migration; artifact/model data are never rewritten."""
from pathlib import Path
import ast
import re

root = Path(__file__).resolve().parent

def read(path):
    return (root / path).read_text(encoding='utf-8')

def write(path, text):
    target = root / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text, encoding='utf-8')

def node_source(source, name):
    node = next(n for n in ast.parse(source).body if getattr(n, 'name', '') == name)
    return '\n'.join(source.splitlines()[node.lineno - 1:node.end_lineno])

# Extract shared utilities before retiring their old command-line programs.
old = read('train_ppo.py')
common = '"""Shared rollout collection, GAE and argument validation."""\n\nimport argparse\nimport random\nfrom rl_platformer.agents.ppo import np\nfrom rl_platformer.envs.platformer import PLAYER_W, PlatformerEnv\nfrom rl_platformer.paths import ROOT, START_RANGE\n\n\n'
write('rl_platformer/training/common.py', common + node_source(old, 'RolloutCollector') + '\n\n\n' + node_source(old, 'positive_int') + '\n')
old = read('run_experiments.py')
write('rl_platformer/utils/io.py', '"""JSON and CSV experiment output."""\n\nimport csv\nimport json\nfrom pathlib import Path\n\n\n' + node_source(old, 'write_json') + '\n\n\n' + node_source(old, 'write_csv') + '\n')

for folder in ('rl_platformer', 'rl_platformer/envs', 'rl_platformer/levels', 'rl_platformer/agents',
               'rl_platformer/training', 'rl_platformer/ui', 'rl_platformer/utils'):
    write(folder + '/__init__.py', '"""' + folder.replace('/', '.') + '."""\n')

modules = {
    'platformer': 'rl_platformer.envs.platformer', 'movement': 'rl_platformer.envs.movement',
    'vision_env': 'rl_platformer.envs.vision', 'procedural': 'rl_platformer.levels.procedural',
    'full_curriculum': 'rl_platformer.levels.full_curriculum', 'height_curriculum': 'rl_platformer.levels.height_curriculum',
    'ppo': 'rl_platformer.agents.ppo', 'vision_agent': 'rl_platformer.agents.vision',
    'train_ppo': 'rl_platformer.training.common', 'run_experiments': 'rl_platformer.utils.io',
    'train_movement': 'rl_platformer.training.state', 'train_vision': 'rl_platformer.training.vision',
    'bootstrap_dash': 'rl_platformer.training.bootstrap_dash', 'game': 'rl_platformer.ui.game',
    'rendering': 'rl_platformer.ui.rendering',
}
for path in list((root / 'rl_platformer').rglob('*.py')) + list((root / 'tests').rglob('*.py')):
    source = path.read_text(encoding='utf-8')
    for name, qualified in modules.items():
        source = re.sub(r'\bfrom ' + name + r' import ', 'from ' + qualified + ' import ', source)
        source = re.sub(r'(?m)^(\s*)import ' + name + r'( as \w+)?$',
                        lambda m: m[1] + 'from ' + qualified.rsplit('.', 1)[0] + ' import ' + name + (m[2] or ''), source)
    source = source.replace('ROOT = Path(__file__).resolve().parent', 'from rl_platformer.paths import ROOT')
    source = source.replace('Path(__file__).with_name(".deps")', 'ROOT / ".deps"')
    source = source.replace('Path(__file__).with_name(".vision_deps")', 'ROOT / ".vision_deps"')
    source = source.replace('ROOT / "experiments" / "dash_speedrun"', 'ROOT / "experiments" / "state" / "dash_speedrun"')
    source = source.replace('ROOT / "experiments" / "dash_demonstrations_v2"', 'ROOT / "experiments" / "state" / "dash_demonstrations_v2"')
    source = source.replace('Path("experiments/movement/policy.json")', 'BASELINE_STATE_POLICY')
    source = source.replace('Path(__file__).parent / "experiments" / "movement" / "policy.json"', 'BASELINE_STATE_POLICY')
    if path.name in ('rendering.py',) or str(path).endswith('agents\\vision.py'):
        source = 'from rl_platformer.paths import ROOT\n' + source
    if 'BASELINE_STATE_POLICY' in source:
        source = 'from rl_platformer.paths import BASELINE_STATE_POLICY\n' + source
    path.write_text(source, encoding='utf-8')

# Generators are shared by current agents; old collector implementations retire.
for name, collector in (('full_curriculum', 'FullCollector'), ('height_curriculum', 'HeightCollector')):
    path = f'rl_platformer/levels/{name}.py'
    source = read(path).split('\n\nclass ' + collector + ':')[0]
    # The class has a base-class suffix.
    source = source.split('\n\nclass ' + collector + '(')[0]
    source = source.replace('from rl_platformer.agents.ppo import np\n', '')
    source = source.replace('from rl_platformer.training.common import RolloutCollector, START_RANGE', 'from rl_platformer.paths import START_RANGE')
    source = source.replace('from rl_platformer.envs.platformer import Level, Platform, PlatformerEnv', 'from rl_platformer.envs.platformer import Level, Platform')
    source = source.replace('from rl_platformer.envs.platformer import PlatformerEnv, ascent_level', 'from rl_platformer.envs.platformer import ascent_level')
    if name == 'height_curriculum':
        source = source.replace('from rl_platformer.levels import full_curriculum\n', '')
    write(path, source.rstrip() + '\n')

# Keep existing short launch commands; implementation lives in the package.
for filename, module in (('game.py', 'rl_platformer.ui.game'), ('play_vision.py', 'rl_platformer.ui.play_vision'),
                         ('train_movement.py', 'rl_platformer.training.state'), ('train_vision.py', 'rl_platformer.training.vision')):
    write(filename, f'"""Command-line entry point; implementation: {module}."""\n\nfrom {module} import main\n\n\nif __name__ == "__main__":\n    raise SystemExit(main())\n')

# Retarget optional requirements after moving the file one directory deeper.
write('requirements/vision.txt', read('requirements/vision.txt').replace('-r requirements.txt', '-r ../requirements.txt'))
print('Package imports, shared helpers, launchers and dependency paths migrated.')
