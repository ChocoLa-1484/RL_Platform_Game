$ErrorActionPreference = 'Stop'
$workspace = [System.IO.Path]::GetFullPath('C:\workspace\RL_PlatGame')
function WorkspacePath([string]$relative) {
    $target = [System.IO.Path]::GetFullPath((Join-Path $workspace $relative))
    if (-not $target.StartsWith($workspace + '\', [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Target outside workspace: $target"
    }
    return $target
}
$moves = [ordered]@{
    'platformer.py'='rl_platformer/envs/platformer.py'
    'movement.py'='rl_platformer/envs/movement.py'
    'vision_env.py'='rl_platformer/envs/vision.py'
    'procedural.py'='rl_platformer/levels/procedural.py'
    'full_curriculum.py'='rl_platformer/levels/full_curriculum.py'
    'height_curriculum.py'='rl_platformer/levels/height_curriculum.py'
    'ppo.py'='rl_platformer/agents/ppo.py'
    'vision_agent.py'='rl_platformer/agents/vision.py'
    'train_movement.py'='rl_platformer/training/state.py'
    'train_vision.py'='rl_platformer/training/vision.py'
    'bootstrap_dash.py'='rl_platformer/training/bootstrap_dash.py'
    'compare_movement.py'='rl_platformer/training/compare_movement.py'
    'game.py'='rl_platformer/ui/game.py'
    'play_vision.py'='rl_platformer/ui/play_vision.py'
    'rendering.py'='rl_platformer/ui/rendering.py'
    'test_full_curriculum.py'='tests/state/test_full_curriculum.py'
    'test_height_curriculum.py'='tests/state/test_height_curriculum.py'
    'test_movement.py'='tests/state/test_movement.py'
    'test_platformer.py'='tests/state/test_platformer.py'
    'test_procedural.py'='tests/state/test_procedural.py'
    'tests_vision/test_vision.py'='tests/vision/test_vision.py'
    'VISION.md'='docs/VISION.md'
    'DASH_V2.md'='docs/DASH_V2.md'
    'easy.pdf'='docs/reference/easy.pdf'
    'Full_version.pdf'='docs/reference/Full_version.pdf'
    'requirements-vision.txt'='requirements/vision.txt'
    'experiments/dash_speedrun'='experiments/state/dash_speedrun'
    'experiments/dash_demonstrations_v2'='experiments/state/dash_demonstrations_v2'
    'experiments/movement'='experiments/state/baseline_v1'
    'artifacts/dash_v2_level13.png'='artifacts/state/dash_v2_level13.png'
    'artifacts/dash_v2_level13_trajectory.json'='artifacts/state/dash_v2_level13_trajectory.json'
    'artifacts/vision_level11.png'='artifacts/vision/vision_level11.png'
    'artifacts/vision_level13.png'='artifacts/vision/vision_level13.png'
}
$retired = @(
    'experiments/dash_demonstrations', 'experiments/movement_dash',
    'experiments/movement_reset', 'experiments/movement_speed', 'experiments/movement_v2',
    'experiments/easy_pdf', 'experiments/full_version', 'experiments/height_curriculum',
    'train_full.py', 'train_height.py', 'plot_experiments.py', 'plot_full.py', 'plot_height.py',
    'requirements-experiments.txt', 'FULL_VERSION.md', 'HEIGHT_CURRICULUM.md', 'MOVEMENT.md',
    'artifacts/height_level13.png', 'artifacts/height_level13_trajectory.json',
    'artifacts/level10.png', 'artifacts/level10_trajectory.json',
    'artifacts/movement_level13.png', 'artifacts/movement_level13_trajectory.json', '__pycache__'
)
# This revised plan only relocates files; it never deletes any content.
# Both source and destination must be inside this workspace and no overwrite is allowed.
foreach ($entry in $moves.GetEnumerator()) {
    $source = WorkspacePath $entry.Key
    $destination = WorkspacePath $entry.Value
    if (-not (Test-Path -LiteralPath $source)) { throw "Missing source: $source" }
    if (Test-Path -LiteralPath $destination) { throw "Destination exists: $destination" }
    if ((Get-Item -LiteralPath $source -Force).Attributes -band [System.IO.FileAttributes]::ReparsePoint) { throw "Reparse source: $source" }
}
foreach ($relative in $retired) {
    $target = WorkspacePath $relative
    $archive = WorkspacePath ('archive/retired/' + $relative)
    if (Test-Path -LiteralPath $archive) { throw "Archive destination exists: $archive" }
    if ((Test-Path -LiteralPath $target) -and ((Get-Item -LiteralPath $target -Force).Attributes -band [System.IO.FileAttributes]::ReparsePoint)) { throw "Reparse source: $target" }
}
$hashes = @{}
foreach ($directory in @('experiments/dash_speedrun','experiments/dash_demonstrations_v2','experiments/movement','experiments/vision')) {
    Get-ChildItem -LiteralPath (WorkspacePath $directory) -File -Recurse | ForEach-Object {
        $relative = $_.FullName.Substring($workspace.Length + 1).Replace('\','/')
        $hashes[$relative] = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
    }
}
$archivedFiles = @()
foreach ($relative in $retired) {
    $target = WorkspacePath $relative
    if (Test-Path -LiteralPath $target -PathType Container) {
        $archivedFiles += Get-ChildItem -LiteralPath $target -File -Recurse | ForEach-Object { $_.FullName.Substring($workspace.Length + 1).Replace('\','/') }
    } elseif (Test-Path -LiteralPath $target) { $archivedFiles += $relative }
}
New-Item -ItemType Directory -Path (WorkspacePath 'docs') -Force | Out-Null
$report = @{moves=$moves; archived_paths=$retired; archived_files=$archivedFiles; preserved_sha256=$hashes; permanent_deletions=@()}
$report | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (WorkspacePath 'docs/cleanup_manifest.json') -Encoding UTF8
foreach ($entry in $moves.GetEnumerator()) {
    $source = WorkspacePath $entry.Key
    $destination = WorkspacePath $entry.Value
    New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
    Move-Item -LiteralPath $source -Destination $destination
}
foreach ($relative in $retired) {
    $target = WorkspacePath $relative
    $archive = WorkspacePath ('archive/retired/' + $relative)
    if (Test-Path -LiteralPath $target) {
        New-Item -ItemType Directory -Path (Split-Path -Parent $archive) -Force | Out-Null
        Move-Item -LiteralPath $target -Destination $archive
    }
}
Write-Output "Moved $($moves.Count) active entries; archived $($archivedFiles.Count) retired files. No files deleted. Preserved hashes are in docs/cleanup_manifest.json."
