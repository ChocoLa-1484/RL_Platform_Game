from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
previous = root / 'archive/retired/README_before_reorganization.md'
if not previous.exists():
    previous.write_bytes((root / 'README.md').read_bytes())

(root / 'README.md').write_text('''# RL Platform Game

PyGame 平台跳躍遊戲，包含 13 個固定關卡、隨機長路線與爬高關卡。支援按住時間決定跳高、八方向衝刺、落地恢復能量；衝刺觸發時先清除原速度再加速。

兩種 agent 分別保存，方便比較：**狀態 PPO** 讀取環境數值，**視覺 CNN** 只接收連續四張畫面。舊實驗已移出工作目錄；現用模型與歷史結果保持原內容。

## 執行

在專案根目錄執行，常用指令不變：

```powershell
# 自己遊玩
python -B game.py --level 13

# 原本的狀態 agent
python -B game.py --agent --level 13 --trace

# 最近儲存的視覺 agent
python -B play_vision.py --level 11

# 開啟即時畫面並訓練新的 CNN；每輪建立獨立目錄
python -B train_vision.py

# 從最新已完成 CNN 接續訓練，另存新一輪
python -B train_vision.py --init-policy experiments/vision/20261020_134343_080697/policy.pt

# 接續訓練狀態 PPO，指定新的輸出目錄
python -B train_movement.py --output-dir experiments/state/my_run
```

遊玩：A/D 或左右移動、Space 按久跳高、Shift/X 搭配方向鍵衝刺、R 重試、`[` / `]` 換關。CNN 訓練視窗：Space 暫停／繼續，Esc 儲存後停止。

## 資料夾

| 路徑 | 內容 |
| --- | --- |
| `rl_platformer/envs/` | 物理、跳躍／衝刺、像素環境 |
| `rl_platformer/levels/` | 隨機關卡生成器；固定關卡在環境模組 |
| `rl_platformer/agents/` | NumPy PPO 與 PyTorch CNN |
| `rl_platformer/training/` | 收集資料、訓練、示範搜尋與評估 |
| `rl_platformer/ui/` | 遊戲、播放與共用繪圖 |
| `experiments/state/` | 原狀態 agent、示範初始化及比較基準 |
| `experiments/vision/` | 每一輪 CNN 的模型、曲線與比較結果 |
| `tests/state/`、`tests/vision/` | 分開執行的測試 |
| `docs/`、`docs/reference/` | 操作文件、結構說明與原始 PDF |
| `artifacts/state/`、`artifacts/vision/` | 截圖與軌跡 |
| `requirements/` | 選用視覺套件需求 |
| `archive/` | 停用版本的可還原封存 |

根目錄四個 `.py` 只負責啟動，實作集中在 `rl_platformer/`。完整搬移紀錄、保留原因與路徑對照見 [專案結構](docs/PROJECT_STRUCTURE.md)。

## 模型與結果

| 模型 | 保存位置 | 已保存測試成績 |
| --- | --- | --- |
| 狀態 PPO（預設） | `experiments/state/dash_speedrun/policy.json` | 920 / 960，95.83% |
| CNN 第一版 | `experiments/vision/cnn_v1/policy.pt` | 74 / 109，67.89% |
| CNN 後續完成版本 | `experiments/vision/20261020_134343_080697/policy.pt` | 81 / 109，74.31% |

CNN 的同批 109 局比較中，狀態 agent 為 106 / 109（97.25%）。不同案例數的百分比不能直接比較；請使用各輪 `results.json` 中的同批結果與配對耗時。

- [視覺 agent 操作、訓練與限制](docs/VISION.md)
- [狀態 agent 與衝刺訓練](docs/DASH_V2.md)
- [最新 CNN 同批比較](experiments/vision/20261020_134343_080697/results.json)

## 安裝與檢查

```powershell
python -m pip install -r requirements.txt

# 狀態與物理測試，不需要 PyTorch
python -B -m unittest discover -s tests/state -v

# 視覺測試，使用獨立程序避免 NumPy/MKL 與 PyTorch 混用
python -B -m unittest discover -s tests/vision -v

# 只重新評估，不覆寫既有結果
python -B train_movement.py --evaluate-only
python -B train_vision.py --evaluate-only experiments/vision/20261020_134343_080697 --no-preview
```

視覺套件安裝見 [VISION.md](docs/VISION.md)。本機 `.deps/` 與 `.vision_deps/` 是仍在使用的套件，保留於根目錄並由 Git 忽略。
''', encoding='utf-8')

path = root / 'docs/VISION.md'
text = path.read_text(encoding='utf-8')
for old, new in (
    ('`rendering.py`', '`rl_platformer/ui/rendering.py`'),
    ('experiments/dash_speedrun/', 'experiments/state/dash_speedrun/'),
    ('requirements-vision.txt', 'requirements/vision.txt'),
    ('python -B -m unittest discover -v', 'python -B -m unittest discover -s tests/state -v'),
    ('python -B -m unittest discover -s tests_vision -v', 'python -B -m unittest discover -s tests/vision -v'),
    ('artifacts/vision_level11.png', 'artifacts/vision/vision_level11.png'),
    ('原本 `models/`、', '現用 '),
):
    text = text.replace(old, new)
text = re.sub(r'\]\((experiments/|artifacts/)', r'](../\1', text)
text = text.replace('## 本次已實測結果', '## 第一版已實測結果')
anchor = '## 獨立輸出'
latest = '''## 後續完成版本

另有完整訓練紀錄保留於 `experiments/vision/20261020_134343_080697/`，沒有覆蓋第一版。已保存結果為 **81 / 109（74.31%）**，同批狀態 agent 為 **106 / 109（97.25%）**；共同成功 80 局，CNN 平均 2.467 秒、狀態 agent 2.440 秒。`play_vision.py` 未指定 `--policy` 時會選擇最近儲存的版本。

完整資料：[後續版本結果](../experiments/vision/20261020_134343_080697/results.json)。

'''
if '## 後續完成版本' not in text:
    text = text.replace(anchor, latest + anchor)
path.write_text(text, encoding='utf-8')

path = root / 'docs/DASH_V2.md'
text = path.read_text(encoding='utf-8')
for old, new in (
    ('`movement.py`', '`rl_platformer/envs/movement.py`'),
    ('`bootstrap_dash.py`', '`rl_platformer/training/bootstrap_dash.py`'),
    ('experiments/dash_speedrun/', 'experiments/state/dash_speedrun/'),
    ('experiments/dash_demonstrations_v2/', 'experiments/state/dash_demonstrations_v2/'),
    ('experiments/movement/', 'experiments/state/baseline_v1/'),
    ('python bootstrap_dash.py', 'python -m rl_platformer.training.bootstrap_dash'),
    ('python compare_movement.py', 'python -m rl_platformer.training.compare_movement'),
    ('experiments/my_dash', 'experiments/state/my_dash'),
    ('artifacts/dash_v2_level13', 'artifacts/state/dash_v2_level13'),
    ('python -m unittest -v', 'python -B -m unittest discover -s tests/state -v'),
):
    text = text.replace(old, new)
text = re.sub(r'\]\((experiments/|artifacts/)', r'](../\1', text)
text = text.replace('較穩定而較慢的 v2 候選保留於 `experiments/movement_v2/policy.json`，可用 `--policy` 指定；它不屬於預設速度模型。',
                    '未採用的中間候選已移至舊版封存，現用版本與比較基準保留於 `experiments/state/`。')
text = text.replace('--output experiments/state/dash_speedrun/comparison.json', '--output experiments/state/new_comparison.json')
text = text.replace('--screenshot artifacts/state/dash_v2_level13.png --trajectory artifacts/state/dash_v2_level13_trajectory.json',
                    '--screenshot artifacts/state/new_level13.png --trajectory artifacts/state/new_level13_trajectory.json')
text = text.replace('v1 的實驗紀錄見 [MOVEMENT.md](MOVEMENT.md)。`--classic` 繼續提供固定跳高、無衝刺的原模式。',
                    'v1 比較基準保留於 `experiments/state/baseline_v1/`。固定跳高、無衝刺的舊實驗及其 `--classic`／`--auto-jump` 遊戲入口已停用，歷史資料可從 `archive/` 還原；目前入口專用於跳躍／衝刺 agent。')
path.write_text(text, encoding='utf-8')
print('Updated README and current agent documentation.')
